Imports ESRI.ArcGIS.esriSystem



Imports ESRI.ArcGIS.GeoDatabaseDistributed
Imports ESRI.ArcGIS.Geodatabase
Imports System.Runtime.InteropServices
Imports System.IO ' added for Replica logs/reporting 4/8/09
Imports System.Net.Mail
Module Module1
    Private m_AOLicenseInitializer As LicenseInitializer = New AutomateReplica_cSharp.LicenseInitializer()
    Public baseName As String

    <STAThread()> _
    Sub Main()
        'ESRI License Initializer generated code.
        m_AOLicenseInitializer.InitializeApplication(New esriLicenseProductCode() {esriLicenseProductCode.esriLicenseProductCodeAdvanced}, _
        New esriLicenseExtensionCode() {})
        'ESRI License Initializer generated code.
        'Do not make any call to ArcObjects after ShutDownApplication()
        m_AOLicenseInitializer.ShutdownApplication()



        '*******************************************************************************************
        ' Start of Replica Program -Rick Engineering
        ' 
        ' Last updated December 28, 2008
        ' 
        ' By Nader Al-Alem
        ' 
        ' Description of Program:
        '
        ' This was developed to Sycnronize the edits in the OtayMaint Geodatabase Instance on 'gissqlcl1' 
        ' to the OtayPub on the same server. It was agreed to hard code the connection
        ' information so that this program can be run from an operating system schedule tasked without 
        ' having to worry about parameters. For this program there are 12 parameters. 
        '
        ' Here is the process:
        '
        ' Step 1.  Establish a GeodataServer instance for the Parent GDB. here the connecion parameters
        '          for the Parent GDB (otayMaint) are entered
        ' 
        ' Step 2. Connect to the Parent Geodatabase. This is an initialization process. This calls
        '         the "IntitializeGEodataServerFromconnectionString" subroutine below. See notes on 
        '         the source of this data.
        '
        ' Step 3. Create a Parent Replica object using GPReplica Object Class.
        '
        ' Step 4. Associate the Parent Replica created in step 3 to the OtayPublish Replica in the 
        '         Parent Geodatabase (the OtayPublish was created Manually in Arcmap). This calls the 
        '         "GetReplica" function. This function is an adaptation from the the following EDN
        '         Article: http://edndoc.esri.com/arcobjects/9.2/NET/8280cca2-b4cf-4d37-8b28-4ee02aaf37e5.htm
        '
        ' Step 5. Repeat steps 1 to create a Geodataserver instance for the Child Geodatabase 
        '
        ' Step 6. Repeat step 2 to connect to the Child Geodatabase
        '
        ' Step 7. Repeat step 3 to create a Child Replica
        '
        ' Step 8. Repeat step 4 to associate teh replica created in step 7 with the OtayPublish replica
        '         in the child Geodatabase.
        '
        ' Step 9. Create/Declare a new replica agent.
        '
        ' Step 10. Use the agent created in step 9 to perform the sync.
        '
        ' Code updated 4/8/09 to produce reports
        '
        ' Step 11. Start writing to the Log file (this is the header part) added 4/8/09
        '
        'Code updated 6/14/09
        '
        ' Step 12. Run T-SQL Script that compares the two geodatabases. Compares number of records in Business,A and D tables
        ' (Added 6/14/09)   
        '
        'Step 13. Append the temporary file created in step 12 to the main log file opened in step 11.
        '
        'Step 14. Cleaning up and deleting the temporary file created in step 12.
        '
        '**********************************************************************************************

        'The following was added for replication reports/logs 4/8/09

        ' modified program to use String Builder 

        'Dim RepWriter As StreamWriter
        Dim Replicalog As String
        Dim StrBuilder As New System.Text.StringBuilder


        'To get today's date
        Dim Mytime As Date
        Mytime = Now()

        'Synchronize file location
        Dim SyncDir As String
        SyncDir = "c:\AutomateReplica\"

        'Synchronize file name
        Replicalog = SyncDir + "Sync_log_" + _
                     Mytime.DayOfWeek.ToString + "_" + _
                     Mytime.Month.ToString + "_" + _
                     Mytime.Day.ToString + "_" + _
                     Mytime.Year.ToString + "_" + _
                     Mytime.Hour.ToString + "_" + _
                     Mytime.Minute.ToString + "_" + _
                     Mytime.Second.ToString + ".log"

        'RepWriter = New StreamWriter(Replicalog)

        ' the following lines replaced with String Builder 01/11/10

        'RepWriter.WriteLine("Syncronization Report On " + Mytime.ToString)
        'RepWriter.WriteLine("==============================================")
        'RepWriter.WriteLine()

        StrBuilder.AppendLine("Syncronization Report On " + Mytime.ToString)
        StrBuilder.AppendLine("==============================================")
        StrBuilder.AppendLine(" ")

        ' To Send email 
        Dim MailMsg As MailMessage
        MailMsg = New MailMessage



        Try

            'Step 1. declarations for Parent connection
            Dim ParentConnection As String
            Dim ParentGDB As IGeoDataServer = New GeoDataServerClass()
            ParentConnection = "INSTANCE=sde:sqlserver:gis-sql2012;DATABASE=OTAYMAINT;VERSION=sde.default;AUTHENTICATION_MODE=DBMS;USER=otaydata;PASSWORD=0wdg1$data"
            'ParentConnection = "Server=owd-gissqlcl1; INSTANCE=sde:sqlserver:sde:sqlserver:owd-gissqlcl-vs;DATABASE=OTAYMAINT;VERSION=sde.default;AUTHENTICATION_MODE=DBMS;USER=otaydata;PASSWORD=otaydata"

            'Step 2. Connect to Parent Geodatabase
            ParentGDB = InitGeoDataServerFromConnectionString(ParentConnection) 'See Function below

            'Step 3. Declare Parent Replica
            Dim ParentReplica As GPReplica
            ParentReplica = Nothing

            'Step 4. Get MyReplica from Parent Geodatabase
            'ParentReplica = GetReplica(ParentGDB, "otaydmd_otaydata9") 'See function below 
            ParentReplica = GetReplica(ParentGDB, "Replica_OtayPublish") 'See function below 

            'For verification and testing
            Dim repName As String
            repName = baseName


            'Step 5. declaration for Child Connection
            Dim Childconnection As String
            Dim ChildGDB As IGeoDataServer = New GeoDataServerClass()
            Childconnection = "INSTANCE=sde:sqlserver:gis-sql2012;DATABASE=OTAYPUBLISH;VERSION=sde.default;Authentication_mode=DBMS; USER=otaydata;PASSWORD=0wdg1$data"
            'Childconnection = "Server=owd-gissqlcl1; INSTANCE=sde:sqlserver:owd-gissqlcl-vs;DATABASE=OTAYPUB;VERSION=sde.default;Authentication_mode=DBMS; USER=otaydata;PASSWORD=otaydata"

            'Step 6. Connect to Child Geodatabase
            ChildGDB = InitGeoDataServerFromConnectionString(Childconnection) 'See Function below

            'Step 7. Declare Child Replica
            Dim ChildReplica As GPReplica
            ChildReplica = Nothing

            'Step 8. Get MyRreplica from Child Geodatabase
            'ChildReplica = GetReplica(ChildGDB, "otaydmd_otaydata9") 'See Function below
            ChildReplica = GetReplica(ChildGDB, "Replica_OtayPublish") 'See Function below

            'For Verification
            repName = baseName

            'Step 9. Declare replication Agent
            Dim replicationAgent As IReplicationAgent = New ReplicationAgentClass()

            'Step 10. Perform Sync.
            replicationAgent.SynchronizeReplica(ParentGDB, ChildGDB, ParentReplica, ChildReplica, esriReplicationAgentReconcilePolicy.esriRAResolveConflictsInFavorOfReplica1, esriReplicaSynchronizeDirection.esriReplicaSynchronizeFromReplica1ToReplica2, True) ' (ParentGDB, ChildGDB, ParentReplica, ChildReplica, esriReplicationAgentReconcilePolicy.esriRAResolveConflictsInFavorOfReplica1, esriReplicaSynchronizeDirection.esriReplicaSynchronizeFromReplica1ToReplica2, False)

            'MessageBox.Show("success")
            Console.WriteLine("Success")
            Mytime = Now()

            'Step 11. Start writing to the Log file (this is the header part)
            ' The following lines were replaced with String builder 01/11/10:

            'RepWriter.WriteLine("The Synchronization was Successful")
            'RepWriter.WriteLine("Synchronization ended at : " + Mytime.ToString)
            'RepWriter.WriteLine("")
            'RepWriter.WriteLine("Comapring Replica database tables")
            'RepWriter.WriteLine("=================================")

            StrBuilder.AppendLine("The Synchronization was Successful")
            StrBuilder.AppendLine("Synchronization ended at : " + Mytime.ToString)
            StrBuilder.AppendLine("")
            StrBuilder.AppendLine("Comapring Replica database tables")
            StrBuilder.AppendLine("=================================")


            'Step 12. Run T-SQL Script that compares the two geodatabases. Compares number of records in Business,A and D tables
            ' (Added 6/14/09)        
            ' The following lines create a temporary file to run the sql script -- Added 06/14/09
            ' These lines enable running a command prompt from within Vb.net

            Dim args As String
            args = "-S gis-sql2012 -i " + SyncDir + "VerifyRelplica_OtayPublish.sql -o " + Replicalog + "1"

            Dim proc As New Process
            proc.StartInfo.FileName = "C:\Program Files\Microsoft SQL Server\100\Tools\Binn\sqlcmd.exe"
            proc.StartInfo.Arguments = args
            proc.StartInfo.UseShellExecute = False
            proc.StartInfo.RedirectStandardOutput = True
            proc.StartInfo.RedirectStandardError = True
            proc.Start()
            'System.IO.File.AppendAllText(Replicalog, proc.StandardOutput.ReadToEnd())
            proc.WaitForExit()
            'System.IO.File.AppendAllText(Replicalog, proc.StandardOutput.ReadToEnd())
            proc.Close()

            'Step 13. Append the temporary file created in step 12 to the main log file opened in step 11.
            '
            ' The following lines were added to concatenate the SQL Server script result into the main log file
            ' Again, it uses the command prompt. similar to the one before it. Here it has to be different, because
            ' in the previous lines, there is an SQLCMD.exe. However, in the next example, we are using dos OS
            ' Commands, so it has to be handled differently. 
            'RepWriter.Close()

            'Dim MyProcess As New ProcessStartInfo
            'args = "/c type " + Replicalog + "1 >> " + Replicalog
            'MyProcess.FileName = System.Environment.GetEnvironmentVariable("ComSpec")
            'MyProcess.Arguments = args
            'Process.Start(MyProcess)

            Dim myscript As String()
            myscript = File.ReadAllLines(Replicalog + "1")

            Dim mystr As String
            Dim myline As String

            File.AppendAllText(Replicalog, StrBuilder.ToString)


            For Each mystr In myscript
                myline = mystr + vbCrLf
                File.AppendAllText(Replicalog, myline)
            Next

            File.AppendAllText(Replicalog, "Synchronization Attempt ended at : " + Mytime.ToString)

            Console.WriteLine("pause")

            'Step 14. Cleaning up and deleting the temporary file created in step 12.
            'deleting the temporary file 
            Dim Cleanup As New ProcessStartInfo
            args = "/c del " + Replicalog + "1"
            Cleanup.FileName = System.Environment.GetEnvironmentVariable("ComSpec")
            Cleanup.Arguments = args
            Process.Start(Cleanup)

            'RepWriter.Close()
            'RepWriter.Close()

        Catch comExc As COMException
            Dim RepWriter As New StreamWriter(Replicalog, True)
            RepWriter.WriteLine("Bad News Dude (or otherwise)!")
            RepWriter.WriteLine()
            RepWriter.WriteLine("Synchronization process faild for the following reasons:")
            RepWriter.WriteLine()
            RepWriter.WriteLine("Create Replica Errored : " + comExc.Message.ToString)
            RepWriter.WriteLine()
            RepWriter.WriteLine("Error Code : " + comExc.ErrorCode.ToString)
            RepWriter.WriteLine()

            Mytime = Now()

            RepWriter.WriteLine("Synchronization Attempt ended at : " + Mytime.ToString)
            RepWriter.Close()

            MailMsg.From = New MailAddress("Nader.AlAlem@otaywater.gov")
            MailMsg.To.Add("nader@halax2.com")
            MailMsg.CC.Add("dongxing.ma@otaywater.gov")
            MailMsg.CC.Add("mzhao@otaywater.gov")
            MailMsg.Subject = "Synchronize Failure Notification"
            MailMsg.Body = "Synchronization process faild for the following reasons:" + vbCrLf + _
                           "Create Replica Errored : " + comExc.Message.ToString + vbCrLf + _
                           "Error Code : " + comExc.ErrorCode.ToString + vbCrLf '+ _
            '"Inner Exception" + comExc.InnerException.ToString + vbCrLf
            Dim smtp As SmtpClient
            'smtp = New SmtpClient("OWD-Exch1.otay.local")
            smtp = New SmtpClient("exrelay-ca1.serverdata.net")
            smtp.Send(MailMsg)







            Throw New Exception(String.Format("Create replica errored: {0}, Error Code: {1}", comExc.Message, comExc.ErrorCode), comExc)


        Catch exc As Exception
            Dim RepWriter1 As New StreamWriter(Replicalog, True)

            RepWriter1.WriteLine("Bad News Dude (or otherwise)!")
            RepWriter1.WriteLine()
            RepWriter1.WriteLine("Synchronization process faild for the following reasons:")
            RepWriter1.WriteLine()
            RepWriter1.WriteLine("Create Replica Errored : " + exc.Message.ToString)
            RepWriter1.WriteLine()
            RepWriter1.WriteLine("Error Code (system exception): " + exc.Message.ToString)
            RepWriter1.WriteLine()

            Mytime = Now()

            RepWriter1.WriteLine("Synchronization Attempt ended at : " + Mytime.ToString)
            RepWriter1.Close()

            MailMsg.From = New MailAddress("mzhao@otaywater.gov")
            MailMsg.To.Add("nader@halax2.com")
            MailMsg.CC.Add("dongxing.ma@otaywater.gov")
            MailMsg.CC.Add("mzhao@otaywater.gov")
            MailMsg.Subject = "Synchronize Failure Notification"
            MailMsg.Body = "Synchronization process faild for the following reasons:" + vbCrLf + _
                           "Create Replica Errored : " + exc.Message.ToString + vbCrLf + _
                           "Error Code (system exception): " + exc.Message.ToString + vbCrLf '+ _
            '"Inner Exception" + comExc.InnerException.ToString + vbCrLf
            Dim smtp As SmtpClient
            smtp = New SmtpClient("64.78.22.99")
            smtp.Send(MailMsg)
            'Throw New Exception(String.Format("Create replica errored: {0}", exc.Message), exc)
        End Try
    End Sub
    Public Function GetReplica(ByVal ParentGDS As IGeoDataServer, ByVal replicaname As String) As IGPReplica

        Dim gpReplicas As IGPReplicas = ParentGDS.Replicas
        Dim parentReplica As IGPReplica '= Nothing
        For i As Integer = 0 To gpReplicas.Count - 1
            ' See if the unqualified replica name matches the replicaName parameter.
            Dim currentReplica As IGPReplica = gpReplicas.Element(i)
            Dim currentReplicaName As String = currentReplica.Name
            Dim dotIndex As Integer = currentReplicaName.LastIndexOf(".") + 1
            baseName = currentReplicaName.Substring(dotIndex, currentReplicaName.Length - dotIndex)
            If baseName.ToLower() = replicaName.ToLower() Then
                parentReplica = currentReplica
                Exit For
            End If
        Next i

        ' Check to see if the parent replica was found.
        If parentReplica Is Nothing Then
            Throw New ArgumentException("The requested replica could not be found on the parent GDS.")
        End If
        gpReplicas.RemoveAll()

        Return parentReplica
    End Function
    'end sub

    Public Function InitGeoDataServerFromConnectionString(ByVal connectionString As String) As IGeoDataServer

        ' For example, connectionString = "SERVER=bobmk;INSTANCE=5151;VERSION=sde.DEFAULT;USER=gdb;PASSWORD=gdb"
        ' Create the GeoDataServer and cast to the the IGeoDataServerInit interface.
        ' source : http://edndoc.esri.com/arcobjects/9.2/NET/827d50f4-7fa8-40b1-9995-f8234d620207.htm

        Dim geoDataServer As IGeoDataServer = New GeoDataServerClass()
        Dim geoDataServerInit As IGeoDataServerInit = CType(geoDataServer, IGeoDataServerInit)

        ' Initialize the GeoDataServer and return it.
        geoDataServerInit.InitFromConnectionString(connectionString)

        Return geoDataServer

    End Function

End Module
